Launch with `npm start --reset-cache`.

Publish with `expo publish`.